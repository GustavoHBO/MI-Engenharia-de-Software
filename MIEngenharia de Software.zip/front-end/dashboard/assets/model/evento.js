export class evento { 
  id_evento; 
  titulo; 
  local; 
  responsavel; 
  foto_url; 
  atista; 
  horario_visitacao; 
  data_inicio; 
  data_fim; 
  categoria; 
  ativo;

 
  constructor() {} 
}