export class pesquisa { 
  id_pesqusia; 
  titulo; 
  descricao; 
  link; 
  data; 
  Usuario_id_usuario; 
  ativo; 

  constructor() {} 
}