export class exposicao {
  id_exposicao;
  data_inicio;
  data_termino;
  categoria;
  descricao;
  ativo;
  titulo;
  item;
  remove_exposicao;
  edita_exposicao;
  cria_exposicao;

  constructor() {}
}