export class item { 
  id_item;
  material;
  doador;
  funcao;
  procedencia;
  autor;
  origem;
  conservacao;
  colecao;
  categoria;
  classificacao;
  titulo;
  imagem_3d;
  estado_de_consevacao;
  iconologia;
  referencias_bilbiograficas;
  descricao_objeto;
  local;
  data;
  historico;
  ativo;
  dimensaoItem;
  documentacaoFotografica;
  aquisicaoItem;
  caracteristicasEstilisticas;
  constructor() {} 
}