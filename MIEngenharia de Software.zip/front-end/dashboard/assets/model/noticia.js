export class noticia { 
  id_noticia; 
  titulo; 
  descricao; 
  data_publicacao; 
  ativo; 
  Usuario_id_user;
  info_imagens;
 
  constructor() { 
       
  } 
}